-- =============================================
-- Author:		Lauren, Alex, Andres
-- Create date: Feb. 1, 2018
-- Description:	Build Broadcloth DM
-- =============================================
--Create Database
IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE name = N'BroadclothDM')
	CREATE DATABASE BroadclothDM
GO
USE BroadclothDM
--
--
--Delete Existing Tables

--Delete Fact Table
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'FactOrder'
       )
	DROP TABLE FactOrder;

--Delete DimDates Table
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DimDates'
       )
	DROP TABLE DimDates;

--Delete DimCustomer Table
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DimCustomer'
       )
	DROP TABLE DimCustomer;

--Delete DimFactory Table
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DimFactory'
       )
	DROP TABLE DimFactory;

--Delete DimMethod Table
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DimMethod'
       )
	DROP TABLE DimMethod;

--Delete DimProduct Table
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DimProduct'
       )
	DROP TABLE DimProduct;


--Create Tables
--Create DimProduct Table
CREATE TABLE DimProduct
	(Product_SK	INT		IDENTITY(1,1)	CONSTRAINT pk_product PRIMARY KEY,
	Product_AK	INT				NOT NULL,
	Model		NVARCHAR(250)	NOT NULL,
	Size		NUMERIC(18,0)	NOT NULL,
	Color		NVARCHAR(50)	NOT NULL
	);
--Create DimDates Table
CREATE TABLE DimDates
	(Date_SK	INT	CONSTRAINT pk_date PRIMARY KEY,
	Date		DATETIME NOT NULL,
	Date_Name	NVARCHAR(50) NOT NULL,
	Month		INT NOT NULL,
	Month_Name	NVARCHAR(50) NOT NULL,
	Quarter		INT	NOT NULL,
	Quarter_Name NVARCHAR(50) NOT NULL,
	Year		INT	NOT NULL
	);
--Create DimMethod Table
CREATE TABLE DimMethod
	(Method_SK	INT IDENTITY(1,1) CONSTRAINT pk_method PRIMARY KEY,
	Method_AK	INT	NOT NULL,
	Method_Name NVARCHAR(50) NOT NULL
	);
--Create DimFactory Table
CREATE TABLE DimFactory
	(Factory_SK		INT IDENTITY(1,1) CONSTRAINT pk_factory PRIMARY KEY,
	Factory_AK		INT NOT NULL,
	Nation			NVARCHAR(50) NOT NULL,
	City			NVARCHAR(30) NOT NULL,
	Currency		NVARCHAR(20) NOT NULL
	);
--Create DimCustomer Table
CREATE TABLE DimCustomer
	(Customer_SK	INT IDENTITY(1,1) CONSTRAINT pk_customer PRIMARY KEY,
	Customer_AK		INT NOT NULL,
	Company_Name	NVARCHAR(50) NOT NULL,
	City			NVARCHAR(20) NOT NULL,
	Nation			NVARCHAR(50) NOT NULL,
	Currency		NVARCHAR(20) NOT NULl,
	);
--Create FactOrder Table
CREATE TABLE FactOrder
	(Date_SK		INT,
	Customer_SK		INT,
	Factory_SK		INT,
	Method_SK		INT,
	Product_SK		INT,
	Quantity		INT,
	Sale_Price		NUMERIC(38,4),
	Production_Cost NUMERIC(38,4),
	Shipping_Cost	NUMERIC(38,4),
	Quality			NUMERIC(18,0),
	CONSTRAINT pk_factorder PRIMARY KEY(Date_SK, Customer_SK, Factory_SK, Method_SK, Product_SK),
	CONSTRAINT fk_date FOREIGN KEY(Date_SK) REFERENCES DimDates(Date_SK),
	CONSTRAINT fk_customer FOREIGN KEY(Customer_SK) REFERENCES DimCustomer(Customer_SK),
	CONSTRAINT fk_factory FOREIGN KEY(Factory_SK) REFERENCES DimFactory(Factory_SK),
	CONSTRAINT fk_method FOREIGN KEY(Method_SK) REFERENCES DimMethod(Method_SK),
	CONSTRAINT fk_product FOREIGN KEY(Product_SK) REFERENCES DimProduct(Product_SK)
	);