SELECT count(*) as Method_AK,
	ShipMethod
FROM Broadcloth.dbo.Shipment
group by ShipMethod