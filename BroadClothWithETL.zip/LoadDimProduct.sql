SELECT A.ItemID as Product_AK,
	B.ModelDescription AS Model,
	A.ItemSize As Size,
	A.Color As Color
FROM
Broadcloth.dbo.Item A INNER JOIN
Broadcloth.dbo.Model  B ON A.ModelID=B.ModelID