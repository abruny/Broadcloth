SELECT FactoryID AS Factory_AK,
	Nation,
	City,
	BaseCurrency
FROM Broadcloth.dbo.Factory