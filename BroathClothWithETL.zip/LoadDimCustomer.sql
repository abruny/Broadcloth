select CustomerID as Customer_AK,
	CompanyName,
	City,
	Nation,
	BaseCurrency
from Broadcloth.dbo.Customer