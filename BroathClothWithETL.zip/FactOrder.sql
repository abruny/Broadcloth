SELECT OrderItem.OrderID,
	DimProduct.Product_SK,
	DimCustomer.Customer_SK,
	DimFactory.Factory_SK,
	DimMethod.Method_SK,
	DT1.Date_SK AS ShipDate,
	DT2.Date_SK AS OrderDate,	
	OrderItem.OrderQuantity AS Quantity,
	OrderItem.SalePrice,
	ProductionBatch.ProductionCost,
	cast((ShipCost * OrderItem.OrderQuantity)/(SELECT SUM(SHIP2.QuantityShipped) 
							FROM Broadcloth.DBO.ShipmentItem AS SHIP2
							WHERE SHIP2.ShipmentID=Shipment.ShipmentID) AS NUMERIC(38,4)) AS ShippingCost,
	ProductionBatch.QualityRating AS Quality

FROM Broadcloth.dbo.OrderItem
INNER JOIN Broadcloth.DBO.ProductionBatch
ON OrderItem.OrderID=ProductionBatch.OrderID AND OrderItem.ItemID=ProductionBatch.ItemID
INNER JOIN Broadcloth.dbo.CustomerOrder
ON OrderItem.OrderID=CustomerOrder.OrderID
INNER JOIN Broadcloth.DBO.ShipmentItem
ON OrderItem.OrderID=ShipmentItem.OrderID AND OrderItem.ItemID=ShipmentItem.ItemID
INNER JOIN Broadcloth.DBO.Shipment
ON ShipmentItem.ShipmentID=Shipment.ShipmentID
INNER JOIN BroadclothDM.dbo.DimProduct 
ON OrderItem.ItemID=DimProduct.Product_AK
INNER JOIN DimCustomer 
ON CustomerOrder.CustomerID=DimCustomer.Customer_AK
INNER JOIN DimFactory 
ON ProductionBatch.FactoryID=DimFactory.Factory_AK
INNER JOIN DimMethod
ON Shipment.ShipMethod=DimMethod.Method_Name
INNER JOIN DimDate DT1
ON Shipment.ShipDate=DT1.Date
INNER JOIN DimDate DT2
ON CustomerOrder.OrderDate=DT2.Date
